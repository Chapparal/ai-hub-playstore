import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@ai_hub_sessions_v1';
const ONBOARDING_KEY = '@ai_hub_onboarding_seen_v1';

export async function getSessions() {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const sessions = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(sessions)) return [];
    return sessions.sort(
      (a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0),
    );
  } catch (error) {
    console.warn('Não foi possível ler o histórico:', error);
    return [];
  }
}

export async function getSession(id) {
  const sessions = await getSessions();
  return sessions.find((session) => session.id === id) || null;
}

export async function createSession(model) {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    model,
    title: 'Nova conversa',
    messages: [],
    updatedAt: new Date().toISOString(),
  };
}

export async function saveSession(session) {
  const sessions = await getSessions();
  const nextSession = { ...session, updatedAt: new Date().toISOString() };
  const index = sessions.findIndex((item) => item.id === nextSession.id);
  if (index >= 0) {
    sessions[index] = nextSession;
  } else {
    sessions.unshift(nextSession);
  }
  const trimmed = sessions
    .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
    .slice(0, 50);
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
  return nextSession;
}

export async function deleteSession(id) {
  const sessions = await getSessions();
  await AsyncStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(sessions.filter((session) => session.id !== id)),
  );
}

export async function clearAllHistory() {
  await AsyncStorage.removeItem(STORAGE_KEY);
}

export async function hasSeenOnboarding() {
  return (await AsyncStorage.getItem(ONBOARDING_KEY)) === 'true';
}

export async function markOnboardingSeen() {
  await AsyncStorage.setItem(ONBOARDING_KEY, 'true');
}
