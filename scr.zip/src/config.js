export const BACKEND_URL = (
  process.env.EXPO_PUBLIC_BACKEND_URL || 'https://SEU-SERVICO-RENDER.onrender.com'
).replace(/\/$/, '');

export const AI_MODELS = [
  {
    key: 'chatgpt',
    label: 'ChatGPT',
    description: 'Versátil para conversar, criar e resolver problemas.',
    icon: 'chatbubble-ellipses-outline',
    color: '#10A37F',
  },
  {
    key: 'claude',
    label: 'Claude',
    description: 'Cuidadoso, analítico e ótimo para textos longos.',
    icon: 'sparkles-outline',
    color: '#D97757',
  },
  {
    key: 'gemini',
    label: 'Gemini',
    description: 'Explora ideias, explica conceitos e conecta pontos.',
    icon: 'planet-outline',
    color: '#7C83FD',
  },
  {
    key: 'rapido',
    label: 'Flash',
    description: 'Respostas velozes para perguntas do dia a dia.',
    icon: 'flash-outline',
    color: '#FFD166',
  },
];

export const MODEL_BY_KEY = Object.fromEntries(
  AI_MODELS.map((model) => [model.key, model]),
);

export function getModel(key) {
  return MODEL_BY_KEY[key] || AI_MODELS[0];
}
