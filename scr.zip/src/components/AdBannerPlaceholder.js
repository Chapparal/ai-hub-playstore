import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, Text, View } from 'react-native';

import { colors } from '../theme';

/**
 * Monetization slot. Replace this view with BannerAd from
 * react-native-google-mobile-ads after adding the AdMob app IDs in app.json.
 */
export default function AdBannerPlaceholder() {
  return (
    <View style={styles.container} accessibilityLabel="Espaço reservado para anúncio">
      <View style={styles.iconBox}>
        <Ionicons name="megaphone-outline" size={17} color={colors.primary} />
      </View>
      <View style={styles.copy}>
        <Text style={styles.label}>ESPAÇO PARA AD MOB</Text>
        <Text style={styles.text}>Seu banner AdMob aparecerá aqui</Text>
      </View>
      <View style={styles.badge}>
        <Text style={styles.badgeText}>BANNER</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', minHeight: 62, borderRadius: 17, paddingHorizontal: 13, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderStyle: 'dashed' },
  iconBox: { width: 34, height: 34, borderRadius: 11, backgroundColor: '#0E2C1D', alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  copy: { flex: 1 },
  label: { color: colors.primary, fontSize: 9, fontWeight: '900', letterSpacing: 1.2 },
  text: { color: colors.textMuted, fontSize: 12, marginTop: 3 },
  badge: { borderWidth: 1, borderColor: colors.border, borderRadius: 7, paddingHorizontal: 7, paddingVertical: 4 },
  badgeText: { color: colors.textMuted, fontSize: 8, fontWeight: '800', letterSpacing: 0.7 },
});
