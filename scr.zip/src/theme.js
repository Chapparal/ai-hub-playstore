import { Platform } from 'react-native';

export const colors = {
  background: '#121212',
  surface: '#1B1B1B',
  surfaceElevated: '#242424',
  border: '#303030',
  text: '#F5F5F5',
  textMuted: '#A7A7A7',
  primary: '#00E676',
  primaryDark: '#00B85A',
  danger: '#FF6B6B',
  white: '#FFFFFF',
};

export const navigationTheme = {
  dark: true,
  colors: {
    primary: colors.primary,
    background: colors.background,
    card: colors.surface,
    text: colors.text,
    border: colors.border,
    notification: colors.primary,
  },
};

export const cardShadow = Platform.select({
  ios: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.22,
    shadowRadius: 8,
  },
  android: { elevation: 4 },
  default: {},
});
