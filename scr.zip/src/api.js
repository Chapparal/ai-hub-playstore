import { BACKEND_URL } from './config';

const REQUEST_TIMEOUT_MS = 45000;

export async function sendChatMessage({ model, message, history = [] }) {
  if (!BACKEND_URL || BACKEND_URL.includes('SEU-SERVICO-RENDER')) {
    throw new Error(
      'Configure EXPO_PUBLIC_BACKEND_URL em mobile/.env antes de enviar mensagens.',
    );
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(`${BACKEND_URL}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, message, history }),
      signal: controller.signal,
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.detail || `Erro do servidor (${response.status}).`);
    }
    if (!data.reply) {
      throw new Error('O backend não retornou uma resposta válida.');
    }
    return data;
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new Error('A solicitação demorou demais. Tente novamente.');
    }
    if (error instanceof TypeError) {
      throw new Error('Não foi possível conectar ao backend. Confira a URL.');
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}
