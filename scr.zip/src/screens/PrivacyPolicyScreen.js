import { ScrollView, StyleSheet, Text, View } from 'react-native';

import { colors } from '../theme';

const sections = [
  ['1. Informações que coletamos', 'O AI Hub pode processar as mensagens que você envia para gerar respostas. O histórico de conversas é armazenado localmente no seu dispositivo por meio do armazenamento do sistema.'],
  ['2. Uso das informações', 'Usamos o conteúdo enviado exclusivamente para encaminhar sua solicitação ao provedor de modelos de IA configurado pelo aplicativo, gerar a resposta e exibi-la para você. Não vendemos suas informações pessoais.'],
  ['3. Provedores de IA', 'As mensagens podem ser transmitidas ao serviço de IA utilizado pelo backend do AI Hub. Esses provedores podem processar dados conforme suas próprias políticas. Não envie senhas, dados bancários, documentos ou informações sensíveis.'],
  ['4. Publicidade', 'O aplicativo pode exibir anúncios de terceiros, incluindo banners. Parceiros de publicidade podem usar identificadores do dispositivo e dados de uso de acordo com suas próprias políticas e com as opções de consentimento disponíveis.'],
  ['5. Armazenamento e segurança', 'Adotamos medidas razoáveis para proteger o aplicativo. Como nenhum sistema é totalmente seguro, evite inserir informações confidenciais nas conversas. A chave de API fica somente no backend e nunca é incluída no aplicativo.'],
  ['6. Seus controles', 'Você pode apagar o histórico salvo no aparelho a qualquer momento em Configurações → Limpar histórico. Também pode desinstalar o aplicativo para remover os dados locais.'],
  ['7. Crianças', 'O AI Hub não é destinado a crianças menores de 13 anos. Se você acredita que uma criança forneceu dados pessoais, entre em contato para que possamos orientar a remoção.'],
  ['8. Alterações', 'Podemos atualizar esta política para refletir mudanças no produto, na legislação ou nos provedores utilizados. A data da última atualização será informada nesta tela.'],
  ['9. Contato', 'Para dúvidas sobre privacidade, substitua este texto pelo e-mail oficial de suporte do responsável pelo aplicativo antes da publicação na Play Store.'],
];

export default function PrivacyPolicyScreen() {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <View style={styles.hero}>
        <Text style={styles.kicker}>AI HUB · PRIVACIDADE</Text>
        <Text style={styles.title}>Política de Privacidade</Text>
        <Text style={styles.updated}>Modelo para revisão jurídica · Última atualização: outubro de 2026</Text>
      </View>
      <Text style={styles.intro}>Este é um modelo inicial para um aplicativo de inteligência artificial. Revise com um profissional e substitua os campos de contato antes de publicar.</Text>
      {sections.map(([heading, body]) => (
        <View key={heading} style={styles.section}>
          <Text style={styles.heading}>{heading}</Text>
          <Text style={styles.body}>{body}</Text>
        </View>
      ))}
      <View style={styles.notice}><Text style={styles.noticeText}>Importante: esta tela é um template informativo e não constitui aconselhamento jurídico.</Text></View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 22, paddingBottom: 44 },
  hero: { paddingBottom: 23, borderBottomWidth: 1, borderBottomColor: colors.border },
  kicker: { color: colors.primary, fontSize: 10, fontWeight: '900', letterSpacing: 1.8, marginBottom: 12 },
  title: { color: colors.text, fontSize: 30, lineHeight: 36, fontWeight: '800' },
  updated: { color: colors.textMuted, fontSize: 12, marginTop: 10 },
  intro: { color: '#C7C7C7', fontSize: 14, lineHeight: 21, marginTop: 22, marginBottom: 6 },
  section: { marginTop: 22 },
  heading: { color: colors.text, fontSize: 16, fontWeight: '800', marginBottom: 7 },
  body: { color: colors.textMuted, fontSize: 14, lineHeight: 22 },
  notice: { marginTop: 26, padding: 14, borderRadius: 14, backgroundColor: '#2A2515', borderWidth: 1, borderColor: '#5E5121' },
  noticeText: { color: '#E8D88A', fontSize: 12, lineHeight: 18 },
});
