import { Ionicons } from '@expo/vector-icons';
import { useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';

import AdBannerPlaceholder from '../components/AdBannerPlaceholder';
import { clearAllHistory } from '../storage';
import { colors } from '../theme';

function Row({ icon, color = colors.text, title, subtitle, onPress, trailing }) {
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={({ pressed }) => [styles.row, pressed && styles.pressed]}>
      <View style={[styles.rowIcon, { backgroundColor: `${color}18` }]}><Ionicons name={icon} size={20} color={color} /></View>
      <View style={styles.rowCopy}><Text style={styles.rowTitle}>{title}</Text>{subtitle ? <Text style={styles.rowSubtitle}>{subtitle}</Text> : null}</View>
      {trailing || (onPress ? <Ionicons name="chevron-forward" size={18} color={colors.textMuted} /> : null)}
    </Pressable>
  );
}

export default function SettingsScreen({ navigation }) {
  const [notifications, setNotifications] = useState(true);

  function askClearHistory() {
    Alert.alert('Limpar histórico?', 'Todas as conversas salvas neste dispositivo serão removidas.', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Limpar tudo', style: 'destructive', onPress: () => clearAllHistory() },
    ]);
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Text style={styles.kicker}>PERSONALIZE SUA EXPERIÊNCIA</Text>
      <Text style={styles.title}>Configurações</Text>
      <Text style={styles.subtitle}>Controle o app do seu jeito.</Text>

      <Text style={styles.sectionLabel}>GERAL</Text>
      <View style={styles.card}>
        <Row icon="notifications-outline" color={colors.primary} title="Notificações" subtitle="Receber novidades do AI Hub" trailing={<Switch value={notifications} onValueChange={setNotifications} trackColor={{ false: '#3A3A3A', true: '#087C43' }} thumbColor={notifications ? colors.primary : '#999'} />} />
        <View style={styles.divider} />
        <Row icon="trash-outline" color={colors.danger} title="Limpar histórico" subtitle="Apagar todas as conversas deste aparelho" onPress={askClearHistory} />
      </View>

      <Text style={styles.sectionLabel}>PRIVACIDADE E LEGAL</Text>
      <View style={styles.card}>
        <Row icon="shield-checkmark-outline" color="#7C83FD" title="Política de Privacidade" subtitle="Como seus dados são tratados" onPress={() => navigation.navigate('Privacy')} />
        <View style={styles.divider} />
        <Row icon="document-text-outline" color="#FFD166" title="Termos de Uso" subtitle="Disponível antes da publicação" onPress={() => Alert.alert('Termos de Uso', 'Adicione os termos oficiais do aplicativo antes de publicar na Play Store.')} />
      </View>

      <Text style={styles.sectionLabel}>MONETIZAÇÃO</Text>
      <AdBannerPlaceholder />
      <Text style={styles.adNote}>O espaço está preparado para receber um banner AdMob após a configuração dos IDs de produção.</Text>

      <View style={styles.version}><Text style={styles.versionText}>AI Hub - Todas IAs Grátis · versão 1.0.0</Text></View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 22, paddingBottom: 42 },
  kicker: { color: colors.primary, fontSize: 10, fontWeight: '900', letterSpacing: 1.8, marginTop: 8 },
  title: { color: colors.text, fontSize: 30, fontWeight: '800', marginTop: 10 },
  subtitle: { color: colors.textMuted, fontSize: 14, marginTop: 7 },
  sectionLabel: { color: '#6E6E6E', fontSize: 10, fontWeight: '900', letterSpacing: 1.6, marginTop: 30, marginBottom: 10 },
  card: { backgroundColor: colors.surface, borderRadius: 18, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 14 },
  row: { minHeight: 72, flexDirection: 'row', alignItems: 'center' },
  pressed: { opacity: 0.65 },
  rowIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  rowCopy: { flex: 1 },
  rowTitle: { color: colors.text, fontSize: 15, fontWeight: '700' },
  rowSubtitle: { color: colors.textMuted, fontSize: 12, marginTop: 4 },
  divider: { height: 1, backgroundColor: colors.border, marginLeft: 52 },
  adNote: { color: '#666666', fontSize: 11, lineHeight: 16, marginTop: 9 },
  version: { alignItems: 'center', marginTop: 34 },
  versionText: { color: '#555555', fontSize: 11 },
});
