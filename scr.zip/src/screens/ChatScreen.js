import { Ionicons } from '@expo/vector-icons';
import { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

import { sendChatMessage } from '../api';
import { getModel } from '../config';
import { createSession, getSession, saveSession } from '../storage';
import { colors } from '../theme';

const welcomeMessage = (model) => ({
  id: 'welcome',
  role: 'assistant',
  content: `Olá! Eu sou o ${model.label}. Como posso ajudar você hoje?`,
});

function MessageBubble({ message }) {
  const isUser = message.role === 'user';
  return (
    <View style={[styles.messageRow, isUser ? styles.userRow : styles.assistantRow]}>
      {!isUser && (
        <View style={styles.assistantAvatar}>
          <Ionicons name="sparkles" size={14} color={colors.background} />
        </View>
      )}
      <View
        style={[
          styles.bubble,
          isUser ? styles.userBubble : styles.assistantBubble,
          message.isError && styles.errorBubble,
        ]}
      >
        <Text style={[styles.messageText, isUser && styles.userMessageText]}>
          {message.content}
        </Text>
      </View>
    </View>
  );
}

function TypingIndicator() {
  return (
    <View style={[styles.messageRow, styles.assistantRow]} accessibilityLabel="Assistente digitando">
      <View style={styles.assistantAvatar}>
        <Ionicons name="sparkles" size={14} color={colors.background} />
      </View>
      <View style={[styles.bubble, styles.assistantBubble, styles.typingBubble]}>
        <View style={styles.typingDots}>
          <View style={styles.dot} />
          <View style={[styles.dot, styles.dotMiddle]} />
          <View style={styles.dot} />
        </View>
      </View>
    </View>
  );
}

export default function ChatScreen({ route, navigation }) {
  const model = getModel(route.params?.model);
  const sessionIdParam = route.params?.sessionId || null;
  const listRef = useRef(null);
  const sessionIdRef = useRef(sessionIdParam);
  const [messages, setMessages] = useState([welcomeMessage(model)]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingSession, setIsLoadingSession] = useState(true);

  useEffect(() => {
    navigation.setOptions({
      title: model.label,
      headerRight: () => (
        <View style={[styles.headerModelDot, { backgroundColor: model.color }]} />
      ),
    });
  }, [model, navigation]);

  useEffect(() => {
    let active = true;
    sessionIdRef.current = sessionIdParam;
    setIsLoadingSession(true);
    (async () => {
      const session = sessionIdParam ? await getSession(sessionIdParam) : null;
      if (active) {
        setMessages(session?.messages?.length ? session.messages : [welcomeMessage(model)]);
        setIsLoadingSession(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [model, sessionIdParam]);

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 40);
    }
  }, [messages, isLoading]);

  async function persistConversation(nextMessages, fallbackTitle) {
    let id = sessionIdRef.current;
    if (!id) {
      const newSession = await createSession(model.key);
      id = newSession.id;
      sessionIdRef.current = id;
    }
    const firstUserMessage = nextMessages.find((message) => message.role === 'user');
    await saveSession({
      id,
      model: model.key,
      title: (firstUserMessage?.content || fallbackTitle).slice(0, 70),
      messages: nextMessages,
    });
  }

  async function handleSend() {
    const text = input.trim();
    if (!text || isLoading || isLoadingSession) return;

    const userMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
    };
    const previousMessages = messages.filter((message) => message.id !== 'welcome');
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setInput('');
    setIsLoading(true);

    try {
      const response = await sendChatMessage({
        model: model.key,
        message: text,
        history: previousMessages.map(({ role, content }) => ({ role, content })),
      });
      const assistantMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: response.reply,
      };
      const completedMessages = [...nextMessages, assistantMessage];
      setMessages(completedMessages);
      await persistConversation(completedMessages, text);
    } catch (error) {
      const errorMessage = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: error.message || 'Não foi possível responder agora. Tente novamente.',
        isError: true,
      };
      const completedMessages = [...nextMessages, errorMessage];
      setMessages(completedMessages);
      await persistConversation(completedMessages, text);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 88 : 0}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <MessageBubble message={item} />}
          ListFooterComponent={isLoading ? <TypingIndicator /> : null}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        />
        <View style={styles.composerShell}>
          <View style={styles.composer}>
            <TextInput
              value={input}
              onChangeText={setInput}
              placeholder="Digite sua mensagem..."
              placeholderTextColor={colors.textMuted}
              style={styles.input}
              multiline
              maxLength={12000}
              editable={!isLoadingSession && !isLoading}
              onSubmitEditing={Platform.OS === 'ios' ? undefined : handleSend}
            />
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Enviar mensagem"
              onPress={handleSend}
              disabled={!input.trim() || isLoading || isLoadingSession}
              style={({ pressed }) => [
                styles.sendButton,
                (!input.trim() || isLoading || isLoadingSession) && styles.sendDisabled,
                pressed && styles.sendPressed,
              ]}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color={colors.background} />
              ) : (
                <Ionicons name="arrow-up" size={21} color={colors.background} />
              )}
            </Pressable>
          </View>
          <Text style={styles.disclaimer}>As respostas podem conter erros. Verifique informações importantes.</Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.background },
  container: { flex: 1 },
  headerModelDot: { width: 10, height: 10, borderRadius: 5, marginRight: 4 },
  listContent: { padding: 18, paddingBottom: 24, flexGrow: 1 },
  messageRow: { flexDirection: 'row', marginBottom: 16, maxWidth: '91%' },
  userRow: { alignSelf: 'flex-end', justifyContent: 'flex-end' },
  assistantRow: { alignSelf: 'flex-start', alignItems: 'flex-end' },
  assistantAvatar: { width: 26, height: 26, borderRadius: 9, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginRight: 8, marginBottom: 1 },
  bubble: { borderRadius: 18, paddingHorizontal: 15, paddingVertical: 12 },
  userBubble: { backgroundColor: colors.primary, borderBottomRightRadius: 5 },
  assistantBubble: { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderBottomLeftRadius: 5 },
  errorBubble: { backgroundColor: '#351C1C', borderColor: '#703333' },
  messageText: { color: colors.text, fontSize: 15, lineHeight: 22 },
  userMessageText: { color: colors.background, fontWeight: '600' },
  typingBubble: { paddingVertical: 15, paddingHorizontal: 18 },
  typingDots: { flexDirection: 'row', alignItems: 'center' },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.textMuted },
  dotMiddle: { marginHorizontal: 4, backgroundColor: colors.primary },
  composerShell: { paddingHorizontal: 14, paddingTop: 8, paddingBottom: 8, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.background },
  composer: { flexDirection: 'row', alignItems: 'flex-end', borderRadius: 21, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, paddingLeft: 16, paddingRight: 7, paddingVertical: 7 },
  input: { flex: 1, color: colors.text, fontSize: 15, lineHeight: 21, maxHeight: 110, paddingTop: 7, paddingBottom: 7 },
  sendButton: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginLeft: 8 },
  sendDisabled: { backgroundColor: '#3B4A42' },
  sendPressed: { opacity: 0.8 },
  disclaimer: { color: '#666666', fontSize: 10, textAlign: 'center', marginTop: 7 },
});
