import { Ionicons } from '@expo/vector-icons';
import { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { markOnboardingSeen } from '../storage';
import { colors } from '../theme';

const SLIDES = [
  {
    icon: 'sparkles-outline',
    eyebrow: 'BEM-VINDO AO AI HUB',
    title: 'Todas as suas IAs\nem um só lugar.',
    text: 'Converse com diferentes assistentes usando uma experiência simples, rápida e elegante.',
    color: '#00E676',
  },
  {
    icon: 'layers-outline',
    eyebrow: 'ESCOLHA SEU ESTILO',
    title: 'A melhor IA para\ncada momento.',
    text: 'Use modelos versáteis, analíticos ou ultrarrápidos e alterne entre eles quando quiser.',
    color: '#7C83FD',
  },
  {
    icon: 'shield-checkmark-outline',
    eyebrow: 'PRIVACIDADE EM PRIMEIRO LUGAR',
    title: 'Seu histórico,\no seu controle.',
    text: 'As conversas ficam salvas no seu dispositivo. Você pode apagar tudo pelas configurações.',
    color: '#FFD166',
  },
];

export default function OnboardingScreen({ onComplete }) {
  const [index, setIndex] = useState(0);
  const slide = useMemo(() => SLIDES[index], [index]);
  const isLast = index === SLIDES.length - 1;

  async function finish() {
    await markOnboardingSeen();
    onComplete();
  }

  function next() {
    if (isLast) {
      finish();
    } else {
      setIndex((current) => current + 1);
    }
  }

  return (
    <View style={styles.screen}>
      <View style={styles.topBar}>
        <View style={styles.brandRow}>
          <View style={styles.brandMark}><Ionicons name="sparkles" size={15} color={colors.background} /></View>
          <Text style={styles.brand}>AI HUB</Text>
        </View>
        {!isLast && (
          <Pressable onPress={finish} hitSlop={12}>
            <Text style={styles.skip}>Pular</Text>
          </Pressable>
        )}
      </View>

      <View style={styles.illustrationArea}>
        <View style={[styles.glow, { backgroundColor: `${slide.color}18` }]} />
        <View style={[styles.orbit, { borderColor: `${slide.color}33` }]} />
        <View style={[styles.iconCircle, { backgroundColor: `${slide.color}18`, borderColor: `${slide.color}55` }]}>
          <Ionicons name={slide.icon} size={74} color={slide.color} />
        </View>
        <View style={[styles.smallOrb, styles.orbOne, { backgroundColor: slide.color }]} />
        <View style={[styles.smallOrb, styles.orbTwo, { backgroundColor: `${slide.color}AA` }]} />
        <View style={[styles.smallOrb, styles.orbThree, { backgroundColor: `${slide.color}66` }]} />
      </View>

      <View style={styles.copyArea}>
        <Text style={[styles.eyebrow, { color: slide.color }]}>{slide.eyebrow}</Text>
        <Text style={styles.title}>{slide.title}</Text>
        <Text style={styles.text}>{slide.text}</Text>
      </View>

      <View style={styles.bottomArea}>
        <View style={styles.dots}>
          {SLIDES.map((item, dotIndex) => (
            <View key={item.eyebrow} style={[styles.dot, dotIndex === index && { width: 28, backgroundColor: slide.color }]} />
          ))}
        </View>
        <Pressable onPress={next} style={({ pressed }) => [styles.nextButton, pressed && styles.pressed]}>
          <Text style={styles.nextText}>{isLast ? 'Começar agora' : 'Continuar'}</Text>
          <Ionicons name={isLast ? 'checkmark' : 'arrow-forward'} size={20} color={colors.background} />
        </Pressable>
        <Text style={styles.legal}>Ao continuar, você concorda com nossa política de privacidade.</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, paddingHorizontal: 24, paddingTop: 25, paddingBottom: 18 },
  topBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brandRow: { flexDirection: 'row', alignItems: 'center' },
  brandMark: { width: 27, height: 27, borderRadius: 9, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginRight: 9 },
  brand: { color: colors.text, fontSize: 12, fontWeight: '900', letterSpacing: 2.2 },
  skip: { color: colors.textMuted, fontSize: 14, fontWeight: '600' },
  illustrationArea: { flex: 1, minHeight: 285, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  glow: { position: 'absolute', width: 245, height: 245, borderRadius: 125 },
  orbit: { position: 'absolute', width: 245, height: 245, borderRadius: 125, borderWidth: 1, transform: [{ rotate: '22deg' }] },
  iconCircle: { width: 164, height: 164, borderRadius: 82, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  smallOrb: { position: 'absolute', width: 10, height: 10, borderRadius: 5 },
  orbOne: { top: '29%', right: '19%' },
  orbTwo: { bottom: '25%', left: '19%', width: 7, height: 7 },
  orbThree: { top: '22%', left: '22%', width: 5, height: 5 },
  copyArea: { paddingBottom: 22 },
  eyebrow: { fontSize: 11, fontWeight: '900', letterSpacing: 2, marginBottom: 13 },
  title: { color: colors.text, fontSize: 34, lineHeight: 39, fontWeight: '800', letterSpacing: -0.8 },
  text: { color: colors.textMuted, fontSize: 15, lineHeight: 23, marginTop: 16, maxWidth: 340 },
  bottomArea: { alignItems: 'center' },
  dots: { flexDirection: 'row', alignItems: 'center', height: 28, marginBottom: 15 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#3B3B3B', marginHorizontal: 4 },
  nextButton: { width: '100%', height: 56, borderRadius: 18, backgroundColor: colors.primary, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  pressed: { opacity: 0.75 },
  nextText: { color: colors.background, fontSize: 16, fontWeight: '900' },
  legal: { color: '#5F5F5F', fontSize: 10, textAlign: 'center', marginTop: 12 },
});
