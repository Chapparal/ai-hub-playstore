import { Ionicons } from '@expo/vector-icons';
import { useCallback, useState } from 'react';
import {
  Alert,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';

import { getModel } from '../config';
import { deleteSession, getSessions } from '../storage';
import { colors } from '../theme';

function formatDate(value) {
  if (!value) return '';
  return new Date(value).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

export default function HistoryScreen({ navigation }) {
  const [sessions, setSessions] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadSessions = useCallback(async () => {
    setSessions(await getSessions());
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadSessions();
    }, [loadSessions]),
  );

  async function refresh() {
    setRefreshing(true);
    await loadSessions();
    setRefreshing(false);
  }

  function confirmDelete(session) {
    Alert.alert('Excluir conversa?', 'Esta ação remove a conversa apenas deste dispositivo.', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Excluir',
        style: 'destructive',
        onPress: async () => {
          await deleteSession(session.id);
          await loadSessions();
        },
      },
    ]);
  }

  return (
    <View style={styles.screen}>
      <FlatList
        data={sessions}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={colors.primary} />
        }
        contentContainerStyle={[styles.list, sessions.length === 0 && styles.emptyList]}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <View style={styles.emptyIcon}>
              <Ionicons name="time-outline" size={29} color={colors.primary} />
            </View>
            <Text style={styles.emptyTitle}>Seu histórico está vazio</Text>
            <Text style={styles.emptyText}>As conversas que você iniciar aparecerão aqui.</Text>
            <Pressable style={styles.startButton} onPress={() => navigation.navigate('Home')}>
              <Text style={styles.startButtonText}>Começar uma conversa</Text>
            </Pressable>
          </View>
        }
        renderItem={({ item }) => {
          const model = getModel(item.model);
          const lastMessage = item.messages?.[item.messages.length - 1];
          return (
            <Pressable
              onPress={() => navigation.navigate('Chat', { model: item.model, sessionId: item.id })}
              style={({ pressed }) => [styles.sessionCard, pressed && styles.pressed]}
            >
              <View style={[styles.modelIcon, { backgroundColor: `${model.color}22` }]}>
                <Ionicons name={model.icon} size={22} color={model.color} />
              </View>
              <View style={styles.sessionCopy}>
                <View style={styles.sessionTitleRow}>
                  <Text numberOfLines={1} style={styles.sessionTitle}>{item.title || 'Conversa'}</Text>
                  <Text style={styles.date}>{formatDate(item.updatedAt)}</Text>
                </View>
                <Text style={styles.modelName}>{model.label}</Text>
                <Text numberOfLines={1} style={styles.snippet}>{lastMessage?.content || 'Sem mensagens'}</Text>
              </View>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Excluir conversa"
                hitSlop={10}
                onPress={() => confirmDelete(item)}
                style={styles.deleteButton}
              >
                <Ionicons name="trash-outline" size={18} color={colors.textMuted} />
              </Pressable>
            </Pressable>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  list: { padding: 16, paddingBottom: 30 },
  emptyList: { flexGrow: 1, justifyContent: 'center' },
  sessionCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 18, padding: 14, marginBottom: 11 },
  pressed: { opacity: 0.7 },
  modelIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  sessionCopy: { flex: 1, minWidth: 0 },
  sessionTitleRow: { flexDirection: 'row', alignItems: 'center' },
  sessionTitle: { color: colors.text, fontSize: 15, fontWeight: '700', flex: 1, marginRight: 8 },
  date: { color: colors.textMuted, fontSize: 11 },
  modelName: { color: colors.primary, fontSize: 11, fontWeight: '700', marginTop: 4 },
  snippet: { color: colors.textMuted, fontSize: 12, marginTop: 4 },
  deleteButton: { paddingLeft: 11, paddingVertical: 8 },
  emptyState: { alignItems: 'center', paddingHorizontal: 28 },
  emptyIcon: { width: 66, height: 66, borderRadius: 23, backgroundColor: '#0E2C1D', alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  emptyTitle: { color: colors.text, fontSize: 20, fontWeight: '800', textAlign: 'center' },
  emptyText: { color: colors.textMuted, fontSize: 14, lineHeight: 21, textAlign: 'center', marginTop: 8 },
  startButton: { backgroundColor: colors.primary, borderRadius: 14, paddingHorizontal: 18, paddingVertical: 12, marginTop: 22 },
  startButtonText: { color: colors.background, fontSize: 14, fontWeight: '800' },
});
