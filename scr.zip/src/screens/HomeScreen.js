import { Ionicons } from '@expo/vector-icons';
import { useCallback } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import AdBannerPlaceholder from '../components/AdBannerPlaceholder';
import { AI_MODELS } from '../config';
import { cardShadow, colors } from '../theme';

export default function HomeScreen({ navigation }) {
  const openChat = useCallback(
    (model) => navigation.navigate('Chat', { model: model.key, sessionId: null }),
    [navigation],
  );

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.headerRow}>
        <View>
          <View style={styles.brandRow}>
            <View style={styles.brandMark}><Ionicons name="sparkles" size={18} color={colors.background} /></View>
            <Text style={styles.eyebrow}>AI HUB</Text>
          </View>
          <Text style={styles.title}>Um lugar para{`\n`}todas as suas ideias.</Text>
          <Text style={styles.subtitle}>Escolha um assistente e comece uma conversa inteligente.</Text>
        </View>
        <View style={styles.headerActions}>
          <Pressable accessibilityLabel="Abrir histórico" onPress={() => navigation.navigate('History')} style={({ pressed }) => [styles.headerButton, pressed && styles.pressed]}>
            <Ionicons name="time-outline" size={21} color={colors.text} />
          </Pressable>
          <Pressable accessibilityLabel="Abrir configurações" onPress={() => navigation.navigate('Settings')} style={({ pressed }) => [styles.headerButton, pressed && styles.pressed]}>
            <Ionicons name="settings-outline" size={21} color={colors.text} />
          </Pressable>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Escolha seu assistente</Text>
      <View style={styles.grid}>
        {AI_MODELS.map((model) => (
          <Pressable key={model.key} onPress={() => openChat(model)} style={({ pressed }) => [styles.card, pressed && styles.cardPressed]}>
            <View style={[styles.iconBox, { backgroundColor: `${model.color}22` }]}><Ionicons name={model.icon} size={28} color={model.color} /></View>
            <View style={styles.cardTitleRow}><Text style={styles.cardTitle}>{model.label}</Text><Ionicons name="arrow-up-outline" size={18} color={colors.textMuted} /></View>
            <Text style={styles.cardDescription}>{model.description}</Text>
          </Pressable>
        ))}
      </View>

      <View style={styles.freeBanner}>
        <View style={styles.freeIcon}><Ionicons name="flash" size={16} color={colors.background} /></View>
        <View style={styles.freeCopy}><Text style={styles.freeTitle}>Feito para começar grátis</Text><Text style={styles.freeText}>Uma interface simples, quatro modelos e seu histórico no dispositivo.</Text></View>
      </View>

      <View style={styles.adSection}><AdBannerPlaceholder /></View>
      <Text style={styles.footer}>AI Hub · powered by Groq</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  content: { padding: 24, paddingTop: 34, paddingBottom: 36 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  brandRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 18 },
  brandMark: { width: 30, height: 30, borderRadius: 10, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  eyebrow: { color: colors.primary, fontSize: 13, fontWeight: '800', letterSpacing: 2.4 },
  title: { color: colors.text, fontSize: 32, lineHeight: 38, fontWeight: '800', letterSpacing: -0.7 },
  subtitle: { color: colors.textMuted, fontSize: 15, lineHeight: 22, marginTop: 14, maxWidth: 280 },
  headerActions: { flexDirection: 'row', gap: 8 },
  headerButton: { width: 42, height: 42, borderRadius: 14, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.border },
  pressed: { opacity: 0.7 },
  sectionTitle: { color: colors.text, fontSize: 18, fontWeight: '700', marginTop: 40, marginBottom: 16 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 14 },
  card: { width: '47.5%', minHeight: 188, padding: 16, borderRadius: 22, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, ...cardShadow },
  cardPressed: { transform: [{ scale: 0.98 }], borderColor: colors.primary },
  iconBox: { width: 52, height: 52, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginBottom: 22 },
  cardTitleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cardTitle: { color: colors.text, fontSize: 17, fontWeight: '800' },
  cardDescription: { color: colors.textMuted, fontSize: 12, lineHeight: 17, marginTop: 9 },
  freeBanner: { flexDirection: 'row', alignItems: 'center', marginTop: 28, padding: 15, borderRadius: 18, backgroundColor: '#0E2C1D', borderWidth: 1, borderColor: '#145D3A' },
  freeIcon: { width: 30, height: 30, borderRadius: 10, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  freeCopy: { flex: 1 },
  freeTitle: { color: colors.primary, fontSize: 14, fontWeight: '800' },
  freeText: { color: '#B8D8C6', fontSize: 12, lineHeight: 17, marginTop: 3 },
  adSection: { marginTop: 24 },
  footer: { color: '#606060', textAlign: 'center', fontSize: 12, marginTop: 25 },
});
